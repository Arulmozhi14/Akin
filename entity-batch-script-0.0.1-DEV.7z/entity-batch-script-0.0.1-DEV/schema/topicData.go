package schema

// TopicData has a topic for the column name and data in a hash
type TopicData struct {
	Topic string
	Raw   string
}
