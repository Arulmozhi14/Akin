package topics

import (
	"fmt"

	"github.com/thoas/go-funk"
)

var topicMapNames = []int{1, 2, 3, 4}

// GetTopicNames returns the topic(topicMapNames)
var GetTopicNames = funk.Map(topicMapNames, func(topic int) string {
	return fmt.Sprintf("topic%v", topic)
})
